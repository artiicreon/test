//function test(){
//    //alert('value');
//}
//var myVar="<?php echo '5';?>";
//alert(myVar);

//phpVars["value1"]
//phpVars["value2"]
//alert(phpVars);
//jQuery.get('http://drupalbasis.lan/sites/all/themes/drupalbasis/templates/test.php', setimg);
//
//function setimg(data) {        
//       jQuery('#imageid').attr( "src", data );       
//       alert(data);
//    }
var image = jQuery('#logo_image').val();
console.log(alert(image));;
