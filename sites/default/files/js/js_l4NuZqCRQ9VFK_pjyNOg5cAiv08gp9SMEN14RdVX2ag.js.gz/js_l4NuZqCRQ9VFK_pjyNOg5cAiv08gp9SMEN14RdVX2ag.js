function test(){
    //alert('value');
}
var myVar='<?php echo "5";?>';
        alert(myVar);;
